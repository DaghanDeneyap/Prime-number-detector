#include <iostream>
using namespace std;
int main(){
    int num;
    cout << "Your number: ";
    cin >> num;
    for(int i=2;i<num;i++){
        if(num%i==0){
            cout<< "Your number can be divided by "<< i << endl;
        }
    }
}